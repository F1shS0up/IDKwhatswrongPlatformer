<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="biom2" tilewidth="16" tileheight="16" tilecount="36" columns="6">
 <image source="level_1set.png" width="96" height="96"/>
</tileset>
